import React, { Component } from 'react';
import Option1Calendar from './Calendar';
import Tap from './Tap';

class Option1 extends Component {
    render() {
        return (
            <div>
            <Option1Calendar/>
            <Tap/> 
            </div>
        );
    }
}
 export default Option1;